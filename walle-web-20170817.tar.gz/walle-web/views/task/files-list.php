<?php

$this->title = '部署的文件列表';

use yii\helpers\Url;
?>
<div style="margin:-10px 0 10px; background:#eee; text-indent:10px;">日期：<?php echo $linkId ?></div>
<div id="logBox"></div>
<script> 
var $logBox = $('#logBox');
$.ajax({                                                                                                                                         
	url: '<?= Url::to('@web/walle-log/') ?>rsync-<?php echo $linkId ?>.log',
	dataType: 'text',
	success: function(o) {
		if (!o) { o = 'log获取失败。请重试！'; return; }

		o = o.trim().replace(/[\r\n]+/g, '<br />');
		$logBox.html(o);
	}
});
</script>
