<?php
/**
 * @var yii\web\View $this
 */
$this->title = yii::t('walle', 'deploying');
use \app\models\Task;
use yii\helpers\Url;
?>
<style>
    .status > span {
        float: left;
        font-size: 12px;
        width: 14%;
        text-align: right;
    }
    .btn-deploy {
        margin-left: 30px;
    }
    .btn-return {
        /*float: right;*/
        margin-left: 30px;
    }
    .hidden { display: none; }
</style>
<div class="box" style="height: 100%">
<div>
<?php 
function dump($vars, $label = '', $return = false) {
    if (ini_get('html_errors')) {
        $content = "<pre>\n";
        if ($label != '') {
            $content .= "<strong>{$label} :</strong>\n";
        }
        $content .= htmlspecialchars(print_r($vars, true));
        $content .= "\n</pre>\n";
    } else {
        $content = $label . " :\n" . print_r($vars, true);
    }
    if ($return) { return $content; }
    echo $content;
    return null;
}
//dump($task);
//echo $task->project->version;
//echo $task->project->id;
//echo $task->project_id;
?>
</div>
    <h4 class="box-title header smaller red">
            <i class="icon-map-marker"></i><?= \Yii::t('w', 'conf_level_' . $task->project['level']) ?>
            -
            <?= $task->project->name ?>
            ：
            <?= $task->title ?>
            （<?= $task->project->repo_mode . ':' . $task->branch ?> <?= yii::t('walle', 'version') ?><?= $task->commit_id ?>）
            <?php if (in_array($task->status, [Task::STATUS_PASS, Task::STATUS_FAILED])) { ?>
                <button type="submit" class="btn btn-primary btn-deploy" data-id="<?= $task->id ?>"><?= yii::t('walle', 'deploy') ?></button>
            <?php } ?>
            <a class="btn btn-success btn-return" href="<?= Url::to('@web/task/index') ?>"><?= yii::t('walle', 'return') ?></a>
    </h4>
    <div class="status">
        <span><i class="fa fa-circle-o text-yellow step-1"></i><?= yii::t('walle', 'process_detect') ?></span>
        <span><i class="fa fa-circle-o text-yellow step-2"></i><?= yii::t('walle', 'process_pre-deploy') ?></span>
        <span><i class="fa fa-circle-o text-yellow step-3"></i><?= yii::t('walle', 'process_checkout') ?></span>
        <span><i class="fa fa-circle-o text-yellow step-4"></i><?= yii::t('walle', 'process_post-deploy') ?></span>
        <span><i class="fa fa-circle-o text-yellow step-5"></i><?= yii::t('walle', 'process_rsync') ?></span>
        <span style="width: 28%"><i class="fa fa-circle-o text-yellow step-6"></i><?= yii::t('walle', 'process_update') ?></span>
    </div>
    <div style="clear:both"></div>
    <div class="progress progress-small progress-striped active">
        <div class="progress-bar progress-status progress-bar-success" style="width: <?= $task->status == Task::STATUS_DONE ? 100 : 0 ?>%;"></div>
    </div>

    <div class="alert alert-block alert-success result-success" style="<?= $task->status != Task::STATUS_DONE ? 'display: none' : '' ?>">
        <h4><i class="icon-thumbs-up"></i><?= yii::t('walle', 'done') ?></h4>
        <p><?= yii::t('walle', 'done praise') ?></p>
	<!--部署完毕直接显示Log了，不需要再点击一次
	<div id="rsyncLogBtn" style="cursor:pointer;" data-linkid="<?= $task->link_id ?>">查看同步的文件log</div>
	-->
	<div id="linkId"></div>
	<style> 
		#rsyncLog p{ margin:2px 0; }
	</style>
	<div id="rsyncLog"></div>
    </div>

    <div class="alert alert-block alert-danger result-failed" style="display: none">
        <h4><i class="icon-bell-alt"></i><?= yii::t('walle', 'error title') ?></h4>
        <span class="error-msg">
        </span>
        <br><br>
        <i class="icon-bullhorn"></i><span><?= yii::t('walle', 'error todo') ?></span>
    </div>

</div>

<script type="text/javascript">
	// 在Controllers/WalleController.php定义了actionStartDeploy接口方法
    $(function() {
        $('.btn-deploy').click(function() {
            $this = $(this);
            $this.addClass('disabled');
            var task_id = $(this).data('id');
            var action = '';
            var detail = '';
            var timer;
            $.post("<?= Url::to('@web/walle/start-deploy') ?>", {taskId: task_id}, function(o) { 
                action = o.code ? o.msg + ':' : '';
                if (o.code != 0) {
                    clearInterval(timer);
                    $('.progress-status').removeClass('progress-bar-success').addClass('progress-bar-danger');
                    $('.error-msg').text(action + detail);
                    $('.result-failed').show();
                    $this.removeClass('disabled');
                }
            });
            $('.progress-status').attr('aria-valuenow', 10).width('10%');
            $('.result-failed').hide();
            function getProcess() {

                $.get("<?= Url::to('@web/walle/get-process?taskId=') ?>" + task_id, function (o) {
                    data = o.data;
                    // 执行失败
                    if (0 == data.status) {
                        clearInterval(timer);
                        $('.step-' + data.step).removeClass('text-yellow').addClass('text-red');
                        $('.progress-status').removeClass('progress-bar-success').addClass('progress-bar-danger');
                        detail = o.msg + ':' + data.memo + '<br>' + data.command;
                        $('.error-msg').html(action + detail);
                        $('.result-failed').show();
                        $this.removeClass('disabled');
                        return;
                    } else {
                        $('.progress-status')
                            .removeClass('progress-bar-danger progress-bar-striped')
                            .addClass('progress-bar-success')
                    }
                    if (0 != data.percent) {
                        $('.progress-status').attr('aria-valuenow', data.percent).width(data.percent + '%');
                    }
                    if (100 == data.percent) {
                        $('.progress-status').removeClass('progress-bar-striped').addClass('progress-bar-success');
                        $('.progress-status').parent().removeClass('progress-striped');
                        $('.result-success').show();
                        clearInterval(timer)
                    }
                    for (var i = 1; i <= data.step; i++) {
                        $('.step-' + i).removeClass('text-yellow text-red')
                            .addClass('text-green progress-bar-striped')
                    }

				   var memo = data.memo;
					console.log(memo);
				   var idIndex = memo.indexOf('link_id='), endPos, linkId,
					   beginPos = memo.indexOf('=', idIndex) + 1;
				   if (idIndex !== -1) {
						// endPos = memo.indexOf('\/etc', idIndex);
						linkId = memo.substring(beginPos, beginPos+15);

						showRsyncLog(linkId);
						console.log(linkId);
					}

                });

		// $('#rsyncLogBtn').addClass('hidden');
		if($('#rsyncLogBtn').hasClass('hidden')) {return;}
            }
            timer = setInterval(getProcess, 600);
        });
	
	$('#getLinkId').click(function(){
	    $.ajax({
	      url: "<?= Url::to('@web/walle-log/getlinkid.php') ?>",
	      success: function(o) {
		console.log(o);
	      }
	    });
	});
	
	function showRsyncLog(linkId) {
	    var $logBox = $('#rsyncLog');
	    $('#linkId').html('当前log版本：' + linkId);

		var path = 'https://file.qf.56.com/f';
		var projectId = <?= $task->project->id ?>;
		var isClearCdn = projectId === 5 || projectId === 6 || projectId === 11 || projectId === 13;
		switch(projectId) {
			case 5:
				path += '/';
				break;
			case 6:
				path += '/h5/';
				break;
			case 11:
				path += '/h5/vue/';
				break;
			case 13:
				path += '/h5/game/';
				break;
			default:
				path += '/';	
		}
		console.log('isClearCdn: ' + isClearCdn);
		// 获取当前部署文件的rsync log
	    $.ajax({
			url: '<?= Url::to('@web/walle-log/') ?>rsync-'+ linkId +'.log',
			dataType: 'text',
			success: function(o) {
				if (!o) { o = 'log获取失败。请重试！'; return; }
				// o = o.trim().split(/[\r\n]+/);
				/*
				o = o.trim().replace(/[\r\n]+/g, '<br />');
					$logBox.append(o);
				*/

				var oa = o.trim().split(/[\r\n]+/g);
				var logHtml = '', clearUrls = [];
				/*
				*/
				$.each(oa, function(i, d) {
					if ( /^(modjs|script|style|help|flashApp|upload).*?\.(js|html|css|png|jpg|gif|swf)$/.test(d) ) {
						// 拼接显示Log Html
						logHtml += '<p>'+ path + d +'</p>';
						clearUrls.push(path + d);
					}
				});
				$logBox.append(logHtml);
				
				/* 暂时去掉自动清缓存功能
				if (isClearCdn) {
					console.log('请求清除缓存……');
					postClearCdn(clearUrls, $logBox);
				}
				*/
			}
	    });
	}
	
	/**
	 * @method 清缓存接口
	 * @param {Array} url 需要清缓存的地址
	 * @param {NodeList} logBox容器
	 */
	function postClearCdn(url, logBox) {
		if (!url.length || url.length > 300) return false;

		url = url.join(';');
		console.log(url);

		$.post("<?= Url::to('@web/walle/clear-cdn') ?>", {url: url}, function(o) { 
			console.log(o);
			console.log('清除缓存接口返回：'+ o.data);

			if (o.data) {
				console.log('成功追加到清缓存队列');
				logBox.append('<h4 style="margin-top:20px;"><i class="icon-thumbs-up"></i>成功追加到清缓存队列</h4>');
			} else {
				console.log('清缓存失败。msg: '+ o.msg);
			}
		});
	}
		!function() {
			/*
			var url = 'https://file.qf.56.com/f/script/lib/layout/layout-1.0.0.js';
			// var url = '';
            $.post("<?= Url::to('@web/walle/clear-cdn') ?>", {url: url}, function(o) { 
				console.log(o);
			});
			*/
		}();

	/* 部署完毕直接显示Log了，不需要再点击一次
	$('#rsyncLogBtn').click(function() {
	    var $t = $(this), $logBox = $('#rsyncLog');
	    $('#linkId').html('当前log版本：' + linkId);
	    showRsyncLog($t.attr('data-linkid'));
	});
	*/

        var _hmt = _hmt || [];
/*
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.56.com/hm.js?5fc7354aff3dd67a6435818b8ef02b52";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
*/
    })

</script>
