<?php
$file_name="/tmp/walle-log/rsync-20161126-132345.log";
echo $file_name."
";
$fp=fopen($file_name,'r');
//$buffer=fgets($fp);
while(!feof($fp)){
$buffer=fgets($fp);
echo $buffer;
}
fclose($fp);
?>
