<?php
use Url::go('@app\models\Task');
    $task = new Task();

    $linkid = $task->link_id;
    echo $linkid;
    echo dirname(__DIR__);
?>
